package com.example.ecommerce.model.dto;

import com.example.ecommerce.model.enums.OrderStatus;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OrderResponse {
    private Long Id;
    private OrderStatus status;
    private Long memberId;
    private List<OrderItemResponse> items;
}