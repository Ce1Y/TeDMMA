package com.example.ecommerce.controller;

import com.example.ecommerce.model.dto.OrderItemResponse;
import com.example.ecommerce.model.dto.OrderRequest;
import com.example.ecommerce.model.dto.OrderResponse;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.model.entity.Order;
import com.example.ecommerce.model.enums.OrderStatus;
import com.example.ecommerce.service.OrderService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Order API", description = "訂單相關操作")
@RestController
@RequestMapping("api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // 建立訂單
    @PostMapping("/create")
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest orderRequest) {
        Order order = orderService.createOrder(orderRequest);

        OrderResponse response = new OrderResponse();
        response.setId(order.getId());
        response.setStatus(order.getStatus());
        response.setMemberId(order.getMember().getId());
        response.setItems(
                order.getItems().stream()
                        .map(i -> new OrderItemResponse(i.getProduct().getId(), i.getQuantity()))
                        .toList()
        );

        return ResponseEntity.ok(response);
    }

    // 更新訂單狀態
    @PatchMapping("/{orderId}/status")
    public Order updateOrderStatus(@PathVariable Long orderId, @RequestParam OrderStatus status) {
        return orderService.updateOrderStatus(orderId, status);
    }

    // 取得會員訂單
    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<Order>> getMemberOrders(@PathVariable Long memberId) {
        List<Order> orders = orderService.getOrdersByMember(memberId);
        return ResponseEntity.ok(orders);
    }

    // 取得所有訂單
    @GetMapping("/all")
    public ResponseEntity<List<OrderResponse>> listOrders() {
        List<OrderResponse> orders = orderService.getAllOrders();
        return ResponseEntity.ok(orders);
    }
}
