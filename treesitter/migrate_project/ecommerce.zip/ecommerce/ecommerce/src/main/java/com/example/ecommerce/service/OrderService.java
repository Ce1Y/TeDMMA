package com.example.ecommerce.service;

import com.example.ecommerce.model.dto.OrderItemRequest;
import com.example.ecommerce.model.dto.OrderItemResponse;
import com.example.ecommerce.model.dto.OrderRequest;
import com.example.ecommerce.model.dto.OrderResponse;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.model.entity.Order;
import com.example.ecommerce.model.entity.OrderItem;
import com.example.ecommerce.model.entity.Product;
import com.example.ecommerce.repository.MemberRepository;
import com.example.ecommerce.repository.OrderRepository;
import com.example.ecommerce.model.enums.OrderStatus;
import com.example.ecommerce.repository.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.Local;
//import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final MemberService memberService;
    private final ProductService productService;

    @Autowired  // 建構子注入
    public OrderService(OrderRepository orderRepository,
                        MemberService memberService,
                        ProductService productService) {
        this.orderRepository = orderRepository;
        this.memberService = memberService;
        this.productService = productService;
    }

    public Order createOrder(OrderRequest orderRequest) {
        // 確認有此會員
        Member member = memberService.getMemberById(orderRequest.getMemberId());  //TODO: 呼叫memberService

        Order order = new Order();
        order.setMember(member);
        order.setStatus(OrderStatus.CREATED);
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());

        // 將每個商品轉成 OrderItem 並加入 order
        List<OrderItem> orderItems = orderRequest.getItems().stream().map(itemReq -> {
            Product product = productService.getProductById(itemReq.getProductId());   //TODO: 呼叫productService

            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(product);
            orderItem.setQuantity(itemReq.getQuantity());
            orderItem.setOrder(order); // 建立關聯
            return orderItem;
        }).toList();

        order.setItems(orderItems);

        return orderRepository.save(order);
    }

    public Order updateOrderStatus(Long orderId, OrderStatus status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found"));
        order.setStatus(status);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }

    public List<Order> getOrdersByMember(Long memberId) {
        return orderRepository.findByMemberId(memberId);
    }

    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElseThrow(() -> new EntityNotFoundException("Order not found"));
    }

    public List<OrderResponse> getAllOrders() {
        List<Order> orders = orderRepository.findAll();

        return orders.stream().map(order -> {
            OrderResponse resp = new OrderResponse();
            resp.setId(order.getId());
            resp.setMemberId(order.getMember().getId());
            resp.setStatus(order.getStatus());

            List<OrderItemResponse> items = order.getItems().stream().map(item -> {
                OrderItemResponse i = new OrderItemResponse();
                i.setProductId(item.getProduct().getId());
                i.setQuantity(item.getQuantity());
                return i;
            }).toList();

            resp.setItems(items);
            return resp;
        }).toList();
    }

    public void deleteAllOrders() {
        orderRepository.deleteAll();
    }
}
