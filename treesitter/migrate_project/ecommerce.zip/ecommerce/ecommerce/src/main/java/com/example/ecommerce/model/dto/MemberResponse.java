package com.example.ecommerce.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MemberResponse {
    private Long id;
    private String username;
    private String email;
    private String role;
}
