package com.example.ecommerce.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OrderRequest {
    private Long memberId;
    private List<OrderItemRequest> items;
}
