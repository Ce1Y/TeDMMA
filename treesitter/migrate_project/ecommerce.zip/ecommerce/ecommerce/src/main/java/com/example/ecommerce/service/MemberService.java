package com.example.ecommerce.service;

import com.example.ecommerce.model.dto.MemberRegisterRequest;
import com.example.ecommerce.model.dto.MemberResponse;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.repository.MemberRepository;
import jakarta.persistence.EntityNotFoundException;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    public MemberResponse register(MemberRegisterRequest request) {
        if (memberRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }

        Member member = Member.builder()
                .username(request.getUsername())
                .password(request.getPassword())
                .email(request.getEmail())
                .role(Member.Role.MEMBER)
                .build();

        memberRepository.save(member);

        return new MemberResponse(member.getId(),
                                  member.getUsername(),
                                  member.getEmail(),
                                  member.getRole().name());
    }

    public Member getMemberById(Long memberId) {
        return memberRepository.findById(memberId).orElseThrow(() -> new EntityNotFoundException("Member not found"));
    }

    public List<Member> findAll() {
        return memberRepository.findAll();
    }

    public void deleteAllMembers() {
        memberRepository.deleteAll();
    }
}
