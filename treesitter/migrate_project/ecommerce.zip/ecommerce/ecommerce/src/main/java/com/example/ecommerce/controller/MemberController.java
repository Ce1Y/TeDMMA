package com.example.ecommerce.controller;

import com.example.ecommerce.model.dto.MemberRegisterRequest;
import com.example.ecommerce.model.dto.MemberResponse;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.service.MemberService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Member API", description = "會員管理相關操作")
@RestController
@RequestMapping("api/members")
public class MemberController {
    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/all")
    public List<Member> getAllMembers() {
        return memberService.findAll();
    }

    @PostMapping("/register")
    public MemberResponse register(@RequestBody MemberRegisterRequest request) {
        return memberService.register(request);
    }
}
