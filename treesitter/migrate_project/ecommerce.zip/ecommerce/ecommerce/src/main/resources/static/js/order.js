// 初始化頁面
async function init() {
    await loadMembers();
    await loadProducts();
    await loadOrders();
}

// 取得會員列表
async function loadMembers() {
    const res = await fetch("/api/members/all");
    const members = await res.json();
    const select = document.getElementById("memberSelect");
    select.innerHTML = "";
    members.forEach(m => {
        const option = document.createElement("option");
        option.value = m.id;
        option.textContent = `${m.username} (${m.email})`;
        select.appendChild(option);
    });
}

// 取得商品列表
async function loadProducts() {
    const res = await fetch("/api/products/all");
    const products = await res.json();
    const select = document.getElementById("productSelect");
    select.innerHTML = "";
    products.forEach(p => {
        const option = document.createElement("option");
        option.value = p.id;
        option.textContent = `${p.name} - $${p.price}`;
        select.appendChild(option);
    });
}

// 取得訂單列表
async function loadOrders() {
    const res = await fetch("/api/orders/all");
    const orders = await res.json();
    const list = document.getElementById("orderList");
    list.innerHTML = "";
    orders.forEach(o => {
        const li = document.createElement("li");
        const items = o.items
            ? o.items.map(i => `${i.productName} x${i.quantity}`).join(", ")
            : "(無明細)";
        li.textContent = `訂單 #${o.orderId}｜會員: ${o.memberName || o.memberId}｜狀態: ${o.status}｜明細: ${items}`;
        list.appendChild(li);
    });
}

// 建立新訂單
document.getElementById("createOrderForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const memberId = document.getElementById("memberSelect").value;
    const productId = document.getElementById("productSelect").value;
    const quantity = document.getElementById("quantity").value;

    const orderRequest = {
        memberId: parseInt(memberId),
        items: [
            { productId: parseInt(productId), quantity: parseInt(quantity) }
        ]
    };

    const res = await fetch("/api/orders/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderRequest)
    });

    if (res.ok) {
        alert("訂單建立成功！");
        loadOrders();
    } else {
        const msg = await res.text();
        alert("建立失敗：" + msg);
    }
});

window.onload = async () => {
    try {
        await init();
    } catch (err) {
        console.error("載入訂單資料失敗：", err);
    }
};
