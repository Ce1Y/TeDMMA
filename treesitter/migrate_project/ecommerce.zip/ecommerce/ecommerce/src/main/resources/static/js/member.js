async function loadMembers() {
    const res = await fetch("/api/members/all");
    const members = await res.json();
    const list = document.getElementById("memberList");
    list.innerHTML = "";
    members.forEach(m => {
        const li = document.createElement("li");
        li.textContent = `${m.id} - ${m.username} (${m.email})`;
        list.appendChild(li);
    });
}

document.getElementById("registerForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
        const response = await fetch("/api/members/register", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({username, email, password})
        });

        if (response.ok) {
            alert("註冊成功！");
            loadMembers();
            // 清空表單
            document.getElementById("registerForm").reset();
        } else {
            const errorData = await response.json();
            alert("註冊失敗：" + (errorData.message || response.statusText));
        }
    } catch (err) {
        alert("註冊時發生錯誤：" + err.message);
    }
});

window.onload = async () => {
    try {
        await loadMembers();
    } catch (err) {
        console.error("載入會員資料失敗：", err);
    }
};
