async function loadProducts() {
    const res = await fetch("/api/products/all");
    const products = await res.json();
    const list = document.getElementById("productList");
    list.innerHTML = "";
    products.forEach(p => {
        const li = document.createElement("li");
        li.textContent = `${p.id}. ${p.name} - $${p.price}`;
        list.appendChild(li);
    });
}

document.getElementById("addProductForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const price = document.getElementById("price").value;
    const stock = document.getElementById("stock").value;

    try {
        const response = await fetch("/api/products", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({name, price, stock})
        });

        if (response.ok) {
            alert("商品已新增！");
            loadProducts();
            // 清空表單
            document.getElementById("addProductForm").reset();
        } else {
            const errorData = await response.json();
            alert("新增商品失敗：" + (errorData.message || response.statusText));
        }
    } catch (err) {
        alert("新增商品時發生錯誤：" + err.message);
    }
});

window.onload = async () => {
    try {
        await loadProducts();
    } catch (err) {
        console.error("載入商品資料失敗：", err);
    }
};
