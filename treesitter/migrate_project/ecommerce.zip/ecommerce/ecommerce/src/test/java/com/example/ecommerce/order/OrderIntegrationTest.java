package com.example.ecommerce.order;

import com.example.ecommerce.model.dto.MemberRegisterRequest;
import com.example.ecommerce.model.dto.OrderItemRequest;
import com.example.ecommerce.model.dto.OrderRequest;
import com.example.ecommerce.model.dto.OrderResponse;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.model.entity.Order;
import com.example.ecommerce.model.entity.Product;
import com.example.ecommerce.model.enums.OrderStatus;
import com.example.ecommerce.repository.MemberRepository;
import com.example.ecommerce.repository.OrderRepository;
import com.example.ecommerce.repository.ProductRepository;
import com.example.ecommerce.service.MemberService;
import com.example.ecommerce.service.OrderService;
import com.example.ecommerce.service.ProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@Transactional  // 每跑一次會清除假資料
public class OrderIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderRepository orderRepository;

    private Member testMember;
    private Product testProduct;

    @BeforeEach
    void init() {
        testMember = new Member();
        testMember.setUsername("tMember");
        testMember.setPassword("tPassword");
        testMember.setEmail("test@gmail.com");
        testMember.setRole(Member.Role.MEMBER);
        memberRepository.save(testMember);

        testProduct = new Product();
        testProduct.setName("tProduct 1");
        testProduct.setPrice(100);
        testProduct.setStock(10);
        productRepository.save(testProduct);
    }

    @Test
    void createOrder_thenVerify() throws Exception {
        // 建立訂單請求
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setMemberId(testMember.getId());
        orderRequest.setItems(List.of(
                new OrderItemRequest(testProduct.getId(), 2)
        ));

        // 發送 POST /api/orders/create
        MvcResult result = mockMvc.perform(post("/api/orders/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(orderRequest)))
                .andExpect(status().isOk())
                .andReturn();

        // 解析回傳結果
        OrderResponse response = objectMapper.readValue(
                result.getResponse().getContentAsString(),
                OrderResponse.class
        );

        assertNotNull(response.getId());
        assertEquals(OrderStatus.CREATED, response.getStatus());
        assertEquals(testMember.getId(), response.getMemberId());
        assertEquals(1, response.getItems().size());

        Order saved = orderRepository.findById(response.getId()).orElseThrow();
        assertEquals(testMember.getId(), saved.getMember().getId());
        assertEquals(1, saved.getItems().size());
        assertEquals(testProduct.getId(), saved.getItems().get(0).getProduct().getId());
        assertEquals(2, saved.getItems().get(0).getQuantity());
    }
}
