package com.example.ecommerce.order;

import com.example.ecommerce.controller.OrderController;
import com.example.ecommerce.model.dto.OrderItemRequest;
import com.example.ecommerce.model.dto.OrderRequest;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.model.entity.Order;
import com.example.ecommerce.model.entity.OrderItem;
import com.example.ecommerce.model.entity.Product;
import com.example.ecommerce.model.enums.OrderStatus;
import com.example.ecommerce.service.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OrderController.class)
@AutoConfigureMockMvc(addFilters = false) // 關閉所有 Security 過濾器
public class OrderServiceMockTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private OrderService orderService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void createOrder_ShouldReturnOrder_WhenRequestValid() throws Exception {
        // 模擬請求資料
        OrderItemRequest itemReq = new OrderItemRequest();
        itemReq.setProductId(1L);
        itemReq.setQuantity(2);

        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setMemberId(100L);
        orderRequest.setItems(List.of(itemReq));

        // 模擬回傳的訂單資料
        Member mockMember = new Member();
        mockMember.setId(100L);
        mockMember.setUsername("testUser");

        Product mockProduct = new Product();
        mockProduct.setId(1L);
        mockProduct.setName("Test Product");

        OrderItem mockOrderItem = new OrderItem();
        mockOrderItem.setId(10L);
        mockOrderItem.setProduct(mockProduct);
        mockOrderItem.setQuantity(2);

        Order mockOrder = Order.builder()
                .id(123L)
                .member(mockMember)
                .items(List.of(mockOrderItem))
                .status(OrderStatus.CREATED)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Mockito.when(orderService.createOrder(any(OrderRequest.class)))
                .thenReturn(mockOrder);

        // 執行 MockMvc 請求
        mockMvc.perform(post("/api/orders/create").contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(orderRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(123L))
                .andExpect(jsonPath("$.member.id").value(100L))
                .andExpect(jsonPath("$.items[0].product.id").value(1L))
                .andExpect(jsonPath("$.status").value("CREATED"));
    }
}
