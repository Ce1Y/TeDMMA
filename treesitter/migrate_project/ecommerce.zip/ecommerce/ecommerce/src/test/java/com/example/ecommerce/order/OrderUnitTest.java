package com.example.ecommerce.order;

import com.example.ecommerce.model.dto.OrderItemRequest;
import com.example.ecommerce.model.dto.OrderRequest;
import com.example.ecommerce.model.entity.Member;
import com.example.ecommerce.model.entity.Order;
import com.example.ecommerce.model.entity.Product;
import com.example.ecommerce.model.enums.OrderStatus;
import com.example.ecommerce.repository.OrderRepository;
import com.example.ecommerce.service.MemberService;
import com.example.ecommerce.service.OrderService;
import com.example.ecommerce.service.ProductService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class OrderUnitTest {

    @Mock
    private MemberService memberService;

    @Mock
    private ProductService productService;

    @Mock
    private OrderRepository orderRepository;

    @InjectMocks
    private OrderService orderService;

    public OrderUnitTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateOrderSuccess() {
        // 模擬會員與商品
        Member member = new Member();
        member.setId(1L);
        member.setUsername("user");

        Product product = new Product();
        product.setId(1L);
        product.setName("Test Product");

        when(memberService.getMemberById(1L)).thenReturn(member);
        when(productService.getProductById(1L)).thenReturn(product);
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));


        // 建立 OrderRequest
        OrderItemRequest itemReq = new OrderItemRequest();
        itemReq.setProductId(1L);
        itemReq.setQuantity(2);

        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setMemberId(1L);
        orderRequest.setItems(List.of(itemReq));

        // 模擬 save
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Order result = orderService.createOrder(orderRequest);

        // 驗證結果
        assertEquals(member, result.getMember());
        assertEquals(OrderStatus.CREATED, result.getStatus());
        assertEquals(1, result.getItems().size());
        assertEquals(product, result.getItems().get(0).getProduct());
        assertEquals(2, result.getItems().get(0).getQuantity());

        // 驗證 save 有被呼叫
        verify(orderRepository, times(1)).save(any(Order.class));
    }

//    @Test
//    void testCreateOrderMemberNotFound() {
//        // 模擬 memberService 丟出例外
//        when(memberService.getMemberById(1L))
//                .thenThrow(new RuntimeException("Member not found"));
//
//        OrderRequest orderRequest = new OrderRequest();
//        orderRequest.setMemberId(1L);
//        orderRequest.setItems(List.of());
//
//        RuntimeException ex = assertThrows(RuntimeException.class,
//                () -> orderService.createOrder(orderRequest));
//        assertEquals("Member not found", ex.getMessage());
//        verify(orderRepository, never()).save(any());
//    }
//
//    @Test
//    void testCreateOrderProductNotFound() {
//        Member member = new Member();
//        member.setId(1L);
//        member.setUsername("user");
//        when(memberService.getMemberById(1L)).thenReturn(member);
//
//        // 模擬商品找不到
//        when(productService.getProductById(1L))
//                .thenThrow(new RuntimeException("Product not found: 1"));
//
//        OrderItemRequest itemReq = new OrderItemRequest();
//        itemReq.setProductId(1L);
//        itemReq.setQuantity(2);
//
//        OrderRequest orderRequest = new OrderRequest();
//        orderRequest.setMemberId(1L);
//        orderRequest.setItems(List.of(itemReq));
//
//        RuntimeException ex = assertThrows(RuntimeException.class,
//                () -> orderService.createOrder(orderRequest));
//        assertEquals("Product not found: 1", ex.getMessage());
//        verify(orderRepository, never()).save(any());
//    }
}
