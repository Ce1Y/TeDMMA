package com.example.ecommerce.order;

import com.intuit.karate.junit5.Karate;

public class CreateOrderRunnerTest {
//    @Karate.Test
//    Karate testCreateOrder() {
//        return Karate.run("classpath:karate/order/create-order.feature");
//    }
}
