Feature: Create Order API 測試
用於驗證 /api/orders/create 能正確建立訂單

  Background:
    * def baseUrl = 'http://localhost:8080'
    * url baseUrl
    * path 'api/orders/create'
    * header Content-Type = 'application/json'
    * def Base64 = Java.type('java.util.Base64')
    * def auth = Base64.getEncoder().encodeToString('admin:1234'.getBytes('UTF-8'))
    * header Authorization = 'Basic ' + auth

  Scenario: 成功建立訂單
    Given request
      """
      {
        "memberId": 1,
        "items": [
          { "productId": 1, "quantity": 2 }
        ]
      }
      """
    When method post
    Then status 200
#    And match response.id == '#number' //TODO: 完全比對不到
#    And match response.member.id == 1
#    And match response.member.username == '#string'
#    And match response.status == 'CREATED'
#    And match response.items[0].quantity == 2
#    And match response.items[0].product.id == 1

#  Scenario: 會員不存在時返回 404
#    Given request
#      """
#      {
#        "memberId": 999,
#        "items": [
#          { "productId": 1001, "quantity": 1 }
#        ]
#      }
#      """
#    When method post
#    Then status 404
#    And match response.message == 'Member not found'
#
#  Scenario: 商品數量為 0 時返回錯誤
#    Given request
#      """
#      {
#        "memberId": 1,
#        "items": [
#          { "productId": 1, "quantity": 0 }
#        ]
#      }
#      """
#    When method post
#    Then status 400
#    And match response.message == 'Quantity must be greater than zero'
